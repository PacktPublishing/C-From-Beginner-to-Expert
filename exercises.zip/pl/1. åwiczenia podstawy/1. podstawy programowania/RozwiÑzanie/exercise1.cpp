#include <iostream> //W tej linii dodajemy biblioteke standarowa dot. wejscia/wyjscia, biblioteke, kt�ra jest potrzebna do uzywania �cout�

/*
Z �cout� mozna korzystac na 3 rozne sposoby:
1. using namespace std;
Tym sposobem masz dostep do wszystkie co znajduje sie w przestrzeni std
2. using std::cout;
Tym sposobem masz dostep tylko do cout z przestrzeni std
3. std::cout
Tym sposobem mo�esz skorzystac z cout jedynie w lini, w kt�rej zostala wywolana ta instrukcja */


using namespace std;

main()
{
    cout << "Suma 2+2 jest rowna 4"; //Ta linia powinna wypisa� na wyj�ciu wynik dodania 2+2
}


