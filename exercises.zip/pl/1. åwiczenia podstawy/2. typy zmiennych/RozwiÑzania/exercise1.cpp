#include <iostream>

using namespace std;

main() {

    char a;   //poj. znak 1 bajt -128 do 127
    int b;    //l. calkowita 4 bajty -2147483648 do 2147483647
    short c;  //l. calkowita (krotsza) 2 bajty -32768 do 3276
    float d;  //liczba zmiennoprzecinkowa o gorszej precyzji 4 bajty +/- 3.4e +/- 38 (~7 cyfr)
    double f; //liczba zmiennoprzecinkowa o podwojnej precyzji 8 bajtow +/- 1.7e +/- 308 (~15 cyfr)

}
