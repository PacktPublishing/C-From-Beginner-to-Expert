#include <iostream>

using namespace std;

main() {

    int numerPokoju;
    short numerPietra;
    string imieLokatora, nazwiskoLokatora;
    bool posilkiUwzglednione;

}
