#include <iostream>

using namespace std;

main() {

    int minValue, maxValue, elementToCheck;
    bool isContained;

    cout << "Podaj wartosc minimalna: ";
    cin >> minValue;
    cout << "Podaj wartosc maksymalna: ";
    cin >> maxValue;
    cout << "Wartosc do sprawdzenia czy zawiera sie w podanym wczesniej przedziale: ";
    cin >> elementToCheck;

    isContained = (minValue <= elementToCheck) && (elementToCheck <= maxValue);
    cout << "Czy liczba " << elementToCheck << " zawiera sie w przedziale od " << minValue << " do " << maxValue << " ? " << isContained;

}


