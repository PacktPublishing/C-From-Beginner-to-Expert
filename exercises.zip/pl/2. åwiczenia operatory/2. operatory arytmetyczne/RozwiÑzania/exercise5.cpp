#include <iostream>


using namespace std;

main()
{
    double firstElement, secondElement, multiplicationResult;


    cout << "Podaj pierwsza liczbe ";
    cin >> firstElement;
    cout << "Podaj druga liczbe: ";
    cin >> secondElement;

    multiplicationResult = firstElement * secondElement;
    cout << "Pierwsza liczba: " << firstElement << endl;
    cout << "Druga liczba: " << secondElement << endl;
    cout << "Iloczyn: " << multiplicationResult << endl;

}


