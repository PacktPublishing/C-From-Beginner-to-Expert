#include <iostream>


using namespace std;

main()
{
    int firstElement, secondElement, divisionRemainder;


    cout << "Podaj pierwsza liczbe ";
    cin >> firstElement;
    cout << "Podaj druga liczbe: ";
    cin >> secondElement;

    divisionRemainder = firstElement % secondElement;
    cout << "Pierwsza liczba: " << firstElement << endl;
    cout << "Druga liczba: " << secondElement << endl;
    cout << "Reszta z dzielenia: " << divisionRemainder << endl;

}


