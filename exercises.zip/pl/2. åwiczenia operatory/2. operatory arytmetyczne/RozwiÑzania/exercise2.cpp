#include <iostream>

using namespace std;

main()
{
    double temperatureCelsius, temperatureFahrenheit, temperatureKelvin;

    cout << "Podaj temp. w skali Celsiusa: ";
    cin >> temperatureCelsius;

    temperatureFahrenheit = (temperatureCelsius * 9/5) + 32;
    temperatureKelvin = temperatureCelsius + 273.15;

    cout << "Podana temp. w skali Celsiusa: " << temperatureCelsius << endl;
    cout << "Przekonwertowana do Fahrenheit: " << temperatureFahrenheit << endl;
    cout << "Przekonwertowana do Kelvin: " << temperatureKelvin << endl;

}


