#include <iostream>

using namespace std;

main()
{
    double lengthInches, lengthCentimeters;

    cout << "Dlugosc w calach: ";
    cin >> lengthInches;

    lengthCentimeters = lengthInches * 2.54;

    cout << lengthInches << " cali to " << lengthCentimeters << " cm.";

}


