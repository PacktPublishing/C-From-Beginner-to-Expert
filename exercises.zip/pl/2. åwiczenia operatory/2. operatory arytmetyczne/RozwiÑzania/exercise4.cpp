#include <iostream>


using namespace std;

main()
{
    double firstElement, secondElement, subtractionResult;

    cout << "Podaj pierwsza liczbe ";
    cin >> firstElement;
    cout << "Podaj druga liczbe: ";
    cin >> secondElement;

    subtractionResult = firstElement - secondElement;
    cout << "Pierwsza liczba: " << firstElement << endl;
    cout << "Druga liczba: " << secondElement << endl;
    cout << "Roznica: " << subtractionResult << endl;

}


