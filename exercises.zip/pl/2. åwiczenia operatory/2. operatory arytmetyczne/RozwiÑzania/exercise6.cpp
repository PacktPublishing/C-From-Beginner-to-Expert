#include <iostream>


using namespace std;

main()
{
    double firstElement, secondElement, divisionResult;


    cout << "Podaj pierwsza liczbe ";
    cin >> firstElement;
    cout << "Podaj druga liczbe: ";
    cin >> secondElement;

    divisionResult = firstElement / secondElement;
    cout << "Pierwsza liczba: " << firstElement << endl;
    cout << "Druga liczba: " << secondElement << endl;
    cout << "Iloraz: " << divisionResult << endl;

}


