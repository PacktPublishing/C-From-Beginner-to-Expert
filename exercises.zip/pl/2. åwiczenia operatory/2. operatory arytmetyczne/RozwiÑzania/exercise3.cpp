#include <iostream>


using namespace std;

main()
{
    double firstElement, secondElement, additionResult;

    cout << "Podaj pierwsza liczbe: ";
    cin >> firstElement;
    cout << "Podaj druga liczbe: ";
    cin >> secondElement;

    additionResult = firstElement + secondElement;
    cout << "Pierwsza liczba: " << firstElement << endl;
    cout << "Druga liczba: " << secondElement << endl;
    cout << "Suma: " << additionResult << endl;

}


