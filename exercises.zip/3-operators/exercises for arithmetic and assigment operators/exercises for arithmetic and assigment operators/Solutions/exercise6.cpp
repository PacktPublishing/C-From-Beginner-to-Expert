#include <iostream>


using namespace std;

main()
{
    double firstElement, secondElement, divisionResult;

    cout << "This is a simple division program." << endl;
    cout << "Input first number: ";
    cin >> firstElement;
    cout << "Input second number: ";
    cin >> secondElement;

    divisionResult = firstElement / secondElement;
    cout << "First number: " << firstElement << endl;
    cout << "Second number: " << secondElement << endl;
    cout << "Division result: " << divisionResult << endl;

}


