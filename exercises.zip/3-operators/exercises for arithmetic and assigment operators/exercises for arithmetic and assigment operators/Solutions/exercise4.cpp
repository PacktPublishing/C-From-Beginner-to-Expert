#include <iostream>


using namespace std;

main()
{
    double firstElement, secondElement, subtractionResult;

    cout << "This is a simple subtraction program." << endl;
    cout << "Input first number: ";
    cin >> firstElement;
    cout << "Input second number: ";
    cin >> secondElement;

    subtractionResult = firstElement - secondElement;
    cout << "First number: " << firstElement << endl;
    cout << "Second number: " << secondElement << endl;
    cout << "Subtraction result: " << subtractionResult << endl;

}


