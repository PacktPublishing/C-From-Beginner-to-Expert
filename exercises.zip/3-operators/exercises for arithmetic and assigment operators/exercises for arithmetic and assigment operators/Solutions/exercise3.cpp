#include <iostream>


using namespace std;

main()
{
    double firstElement, secondElement, additionResult;

    cout << "This is a simple addition program." << endl;
    cout << "Input first number: ";
    cin >> firstElement;
    cout << "Input second number: ";
    cin >> secondElement;

    additionResult = firstElement + secondElement;
    cout << "First number: " << firstElement << endl;
    cout << "Second number: " << secondElement << endl;
    cout << "Addition result: " << additionResult << endl;

}


