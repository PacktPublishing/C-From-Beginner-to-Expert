#include <iostream>

using namespace std;

struct book
{
    string title;
    string author;
    int publicationYear;
};

int main()
{
    book book1, book2, book3;

    return 0;
}
