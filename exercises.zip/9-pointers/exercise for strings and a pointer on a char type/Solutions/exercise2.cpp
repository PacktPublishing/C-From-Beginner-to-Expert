#include <iostream>

using namespace std;

int main ()
{

    string alphabet = "abcdefghijklmnopqrstuvwxyz";

    for (int i = 0; i < 26; i++)
        cout << alphabet[i];

    return 0;
}

