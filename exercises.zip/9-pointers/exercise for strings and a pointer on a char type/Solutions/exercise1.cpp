#include <iostream>

using namespace std;

int main ()
{

    char alphabet[27] = "abcdefghijklmnopqrstuvwxyz";

    for (int i = 0; i < 26; i++)
        cout << alphabet[i];

    return 0;
}

