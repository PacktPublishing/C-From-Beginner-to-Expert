#include <iostream>

using namespace std;

main() {

    char a;   //character 1 byte -128 to 127
    int b;    //integer 4 bytes -2147483648 to 2147483647
    short c;  //short integer 2 bytes -32768 to 3276
    float d;  //floating point 4 bytes +/- 3.4e +/- 38 (~7 digits)
    double f; //double floating point 8 bytes +/- 1.7e +/- 308 (~15 digits)

}
