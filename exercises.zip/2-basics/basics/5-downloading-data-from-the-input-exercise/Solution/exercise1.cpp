#include <iostream>

using namespace std;

main () {

    string text1, text2, text3;

    cout << "Input first text: ";
    cin >> text1;
    cout << "Input second text: ";
    cin >> text2;
    cout << "Input third text: ";
    cin >> text3;

    cout << "The combination of the three is :" << endl;
    cout << text1 << " " << text2 << " " << text3;
}
