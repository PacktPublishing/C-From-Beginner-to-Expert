#include <iostream>
using namespace std;
//operators
main()
{
    /*
    int a = 10;
    int b = 4;

    cout << a + b << endl; //addition operation
    cout << a - b << endl; //substraction operation
    cout << a * b << endl; //multiplication
    cout << a / b << endl; //division
    //10 % 4 = 2 - remainder 10 - 8 = 2
    //1 % 5 = 1

    cout << a % b << endl;
    //incrementation - increase by 1
    //decrementation - decrease by 1
*/
/*
    int c = 1;

    //c = c + 1;
    c += 1; //it is the same as c = c + 1;

    cout << c << endl;
    */
    /*
        /=, -=, %=, *=
    */

    int d = 1;

    cout << d-- << endl; //++ here is increment operator

    cout << d << endl;

    //POSTincrementation
    //PREincrementation
    //POSTdecrementation
    //PREdecrementation


}
