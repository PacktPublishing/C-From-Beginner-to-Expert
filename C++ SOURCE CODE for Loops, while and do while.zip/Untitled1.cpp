#include <iostream>

using namespace std;

main()
{
    const int SIZEOFARRAY = 10;
    int i = 0;
    int array[SIZEOFARRAY];
/*
    while(i < SIZEOFARRAY) //i = 0
    {
        array[i] = 10 * i;
        cout << array[i++] << endl;
    }
    */
    while (i)
      cout <<"lalala";
/*
    do
    {
        cout << "lala";

    } while(i);
*/
}
