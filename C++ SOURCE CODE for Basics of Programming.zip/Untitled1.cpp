// IOstream stands for Input-Output Stream
#include <iostream>

using namespace std;

main()
{
    cout << "this is test";//COut stands for Console Output
}
