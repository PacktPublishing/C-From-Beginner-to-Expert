#include <iostream>

using namespace std;
//Variables
//INITIALIZATION
//address
//allocate
//Hungarian notation

main()
{
    int A = 4;
    //A = 4;
    //& (ampersand)
    //&name_of_variable;
    int prime_nr;
    int primeNr;
    int iPrimeNr;


    cout << A << endl;
    cout << &A << endl;

    A = 10;

    cout << A << endl;
    cout << &A;
    /*
        1. Variables can't have the same name.
        2. Variables can't start from the number
        3. We can't use spaces
        4. Our variables should be self-descriptive
        5. Variables can't be constructed of special characters, keywords
        6. Variables sould be nouns
    */

}

