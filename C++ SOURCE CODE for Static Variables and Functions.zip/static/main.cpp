#include <iostream>
#include "user.h"

using namespace std;
/*static properties and static methods */

int main()
{


    cout << User::getCounter() << endl;

    return 0;
}
