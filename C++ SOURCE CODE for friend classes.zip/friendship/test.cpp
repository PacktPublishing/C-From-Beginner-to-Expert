#include "test.h"


void A::setSecretValue(B & obj, int value)
{
    obj.secretValue = value;
}
