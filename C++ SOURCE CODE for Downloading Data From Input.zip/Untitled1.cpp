#include <iostream>

using namespace std;

main()
{
    string name, surname;

    cout << "Enter your name: ";
    cin >> name;

    cout << "Enter your surname: ";
    cin >> surname;

    cout << "Welcome " << name << " " << surname;

}
