#include <iostream>
#include "ourfirstlibrary.h"
using namespace std;

int a = 50;
void showHelp()
{
    cout << "this is help" << endl;
}
