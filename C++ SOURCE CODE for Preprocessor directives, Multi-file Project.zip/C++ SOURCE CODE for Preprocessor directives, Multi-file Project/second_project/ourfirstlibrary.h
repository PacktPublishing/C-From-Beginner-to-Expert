#ifndef OURFIRSTLIBRARY_H_INCLUDED
#define OURFIRSTLIBRARY_H_INCLUDED

extern int a; //external (oustide) it means that here we do not reserve MEMORY for variable a
/**
    this is going to help you
*/
void showHelp();

#endif // OURFIRSTLIBRARY_H_INCLUDED
