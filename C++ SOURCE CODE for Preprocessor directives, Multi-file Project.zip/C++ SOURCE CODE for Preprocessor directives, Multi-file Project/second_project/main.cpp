#include <iostream>
#include "ourfirstlibrary.h"
using namespace std;
/* preprocessor directives and multi-file project */

#define PI 3.14

int main()
{
    showHelp();
    cout << a << endl;
    return 0;
}
